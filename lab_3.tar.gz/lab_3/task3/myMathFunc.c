int isEqual(int a,int b){
if(a==b){
   return 1;
}
else
   return -1;
}

void swap(int a,int b)
{

printf("Before swap");
printf("\n");
printf("variable 1:%d" ,a);
printf("\n");
printf("variable 2:%d" ,b);
printf("\n");
a=a+b;
b=a-b;
a=a-b;
printf("After swap");
printf("variable 1:%d" ,a);
printf("\n");
printf("variable 2:%d" ,b);
printf("\n");
}
