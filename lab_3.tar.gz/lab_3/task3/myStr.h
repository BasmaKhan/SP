int Is_Palindrome(char *, int);
