#include<stdio.h>
#include"myMath.h"
#include"myStr.h"
int main(){
swap(4,5);
int val=isEqual(4,5);
if(val==1){
printf("Equal Variables");
printf("\n");
}
else{
printf("Not Equal Variables");
printf("\n");
}
char arr[5]={'B','A','S','M','A'};
int val2=Is_Palindrome(arr,5);

if(val==1){
printf("Palindrome");
printf("\n");
}
else{
printf("Not Palindrome");
printf("\n");
}
}
