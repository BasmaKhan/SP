#include<stdio.h>
#include"myMath.h"
int main(){

int a ,b;
	printf("Enter first variable");
	scanf("%d",&a);

	printf("Enter Second variable");
	scanf("%d",&b);
int val=isEqual(a,b);
if(val==1)
  {
	printf("both variables are equal");
	printf("\n");
  }
else
	printf("both variables are not equal");
	printf("\n");

swap(a,b);

}
