#include<stdio.h>
#include"myStr.h"
int main(){
char arr[5]={'B','A','S','M','A'};
char arr1[5]={'B','A','S','A','B'};
int val=Is_Palindrome(arr1,5);
if(val==1){
printf("palindrome ");
printf("\n");
}
else
printf("Not palindrome ");
printf("\n");
}
