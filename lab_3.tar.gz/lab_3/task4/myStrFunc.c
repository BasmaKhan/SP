int Is_Palindrome(char *arr, int size){
int val=size-1;
int i;
for(i=0;i<size;i++)
  {
	if(arr[val]==arr[i])
	{
		val--;
	}
	else
	{
	return -1;	
	}

  }

return 1;
}
